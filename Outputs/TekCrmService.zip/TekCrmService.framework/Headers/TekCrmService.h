//
//  TekCrmService.h
//  TekCrmService
//
//  Created by Tung Nguyen on 8/10/20.
//  Copyright © 2020 Tung Nguyen. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for TekCrmService.
FOUNDATION_EXPORT double TekCrmServiceVersionNumber;

//! Project version string for TekCrmService.
FOUNDATION_EXPORT const unsigned char TekCrmServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TekCrmService/PublicHeader.h>


